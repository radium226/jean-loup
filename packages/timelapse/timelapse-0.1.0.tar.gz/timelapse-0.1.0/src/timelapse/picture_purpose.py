from enum import StrEnum, auto


class PicturePurpose(StrEnum):

    TIMELAPSE = auto()

    AD_HOC = auto()