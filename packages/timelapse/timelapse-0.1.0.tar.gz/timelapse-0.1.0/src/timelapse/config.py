from pydantic import BaseModel
import pendulum
from pendulum import Time
from pathlib import Path
from typing import Annotated, Any

from pydantic import GetCoreSchemaHandler, GetJsonSchemaHandler
from pydantic.json_schema import JsonSchemaValue
from pydantic_core.core_schema import CoreSchema, chain_schema, str_schema, no_info_plain_validator_function, json_or_python_schema, union_schema, is_instance_schema, plain_serializer_function_ser_schema

class PydanticAnnotationForTime:

    @classmethod
    def __get_pydantic_core_schema__(
        cls,
        _source_type: Any,
        _handler: GetCoreSchemaHandler,
    ) -> CoreSchema:
        """
        We return a pydantic_core.CoreSchema that behaves in the following ways:

        * ints will be parsed as `ThirdPartyType` instances with the int as the x attribute
        * `ThirdPartyType` instances will be parsed as `ThirdPartyType` instances without any changes
        * Nothing else will pass validation
        * Serialization will always return just an int
        """

        def validate_from_str(value: str) -> Time:
            return pendulum.from_format(value, "HH:mm:ss").time()

        from_str_schema = chain_schema(
            [
                str_schema(),
                no_info_plain_validator_function(validate_from_str),
            ]
        )

        return json_or_python_schema(
            json_schema=from_str_schema,
            python_schema=union_schema(
                [
                    # check if it's an instance first before doing any further work
                    is_instance_schema(Time),
                    from_str_schema,
                ]
            ),
            serialization=plain_serializer_function_ser_schema(
                lambda instance: instance.format("HH:mm:ss")
            ),
        )

    @classmethod
    def __get_pydantic_json_schema__(
        cls, _core_schema: CoreSchema, handler: GetJsonSchemaHandler
    ) -> JsonSchemaValue:
        return handler(str_schema())
    

AnnotatedTimeForPydantic = Annotated[Time, PydanticAnnotationForTime]

class Credentials(BaseModel):

    login: str
    password: str


class Hotspot(BaseModel):

    enabled: bool = True
    ssid: str = "bamboo"
    credentials: Credentials | None = None


class TimeLapse(BaseModel):

    enabled: bool = True
    
    wakeup_time: AnnotatedTimeForPydantic = Time(12, 0, 0)


class ConfigValues(BaseModel):

    hotspot: Hotspot = Hotspot()

    time_lapse: TimeLapse = TimeLapse()



class Config():

    DEFAULT_FOLDER_PATH = Path("/etc/timelapse")

    file_path: Path
    _values: ConfigValues | None = None

    def __init__(self, folder_path: Path | None = None):
        self.file_path = ( folder_path or self.DEFAULT_FOLDER_PATH ) / "config.json"

    def __enter__(self) -> ConfigValues:
        values = self._read_values()
        self._values = values
        return values
    
    @property
    def values(self) -> ConfigValues:
        return values if (values := self._values) else self._read_values()
    
    def __exit__(self, type, value, traceback) -> None:
        if (values := self._values):
            self._write_values(values)
    
    def _write_values(self, values: ConfigValues) -> None:
        with self.file_path.open("w") as f:
            f.write(values.model_dump_json(indent=2))

    def _read_values(self) -> ConfigValues:
        if self.file_path.exists():
            with self.file_path.open("r") as f:
                return ConfigValues.model_validate_json(f.read())
        else:
            return ConfigValues()
    
