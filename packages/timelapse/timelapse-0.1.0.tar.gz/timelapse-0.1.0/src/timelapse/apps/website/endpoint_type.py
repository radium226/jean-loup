from enum import StrEnum, auto


class EndpointType(StrEnum):

    UI = auto()
    API = auto()
