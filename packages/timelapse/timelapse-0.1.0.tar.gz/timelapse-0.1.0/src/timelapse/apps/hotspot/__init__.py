from .hotspot import Hotspot


__all__ = [
    "Hotspot",
]