from enum import StrEnum, auto


class PictureFormat(StrEnum):
    JPEG = auto()

    PNG = auto()
