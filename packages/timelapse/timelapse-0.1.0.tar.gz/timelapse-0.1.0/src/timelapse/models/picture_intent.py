from enum import StrEnum, auto


class PictureIntent(StrEnum):

    TIME_LAPSE = auto()

    AD_HOC = auto()