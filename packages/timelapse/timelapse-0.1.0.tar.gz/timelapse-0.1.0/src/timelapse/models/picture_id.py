from typing import TypeAlias


PictureID: TypeAlias = str