from pytest import fixture
from tempfile import TemporaryDirectory
from typing import Generator
from pathlib import Path
from textwrap import dedent
from pendulum import Time

from timelapse.config import Config

@fixture
def settings_folder_path() -> Generator[Path, None, None]:
    with TemporaryDirectory() as temp_folder_path:
        yield Path(temp_folder_path)


@fixture(autouse=True)
def settings_file_path(settings_folder_path: Path) -> Path:
    file_path = settings_folder_path / "config.json"
    with file_path.open("w") as f:
        f.write(
            dedent(
                """\
                    {
                        "hotspot": {
                            "enabled": true,
                            "ssid": "bamboo",
                            "credentials": null
                        },
                        "time_lapse": {
                            "enabled": true,
                            "wakeup_time": "09:00:00"
                        }
                    }
                """
            )
        )
    return file_path


@fixture
def config(settings_folder_path: Path) -> Config:
    return Config(folder_path=settings_folder_path)

def test_config(
    config: Config,    
) -> None:
    with config as config_values:
        assert config_values.hotspot.enabled
        assert config_values.time_lapse.wakeup_time == Time(9, 0, 0)
        config_values.hotspot.enabled = False
    
    with config as config_values:
        assert not config_values.hotspot.enabled